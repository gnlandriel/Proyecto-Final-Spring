package com.dh.proyectoFinal.service;

import com.dh.proyectoFinal.modelo.PacienteDTO;

import java.util.Set;

public interface IPacienteService {
    void agregarPaciente(PacienteDTO pacienteDTO);
    PacienteDTO leerPaciente(Long id);
    void modificarPaciente(PacienteDTO pacienteDTO);
    void eliminarPaciente(Long id);
    Set<PacienteDTO> listarPacientes();
}
