package com.dh.proyectoFinal.service;

import com.dh.proyectoFinal.modelo.Odontologo;
import com.dh.proyectoFinal.modelo.Paciente;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.dh.proyectoFinal.modelo.Turno;
import com.dh.proyectoFinal.modelo.TurnoDTO;
import com.dh.proyectoFinal.repository.ITurnoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Service
public class TurnoService implements ITurnoService{

    @Autowired
    private ITurnoRepository turnoRepository;

    @Autowired
    ObjectMapper mapper;
    @Override
    public void agregarTurno(TurnoDTO turnoDTO) {
        Turno turno = mapper.convertValue(turnoDTO, Turno.class);
        turnoRepository.save(turno);

        /*Turno turnoEntity = new Turno();
        turnoEntity.setFecha(turnoDTO.getFecha());

        Paciente paciente = new Paciente();
        paciente.setId(turnoDTO.getPaciente_id());

        Odontologo odontologo = new Odontologo();
        odontologo.setId(turnoDTO.getOdontologo_id());

        turnoEntity.setPaciente(paciente);
        turnoEntity.setOdontologo(odontologo);

        Turno turnoGuardado = turnoRepository.save(turnoEntity);
        TurnoDTO turnoADevolver = new TurnoDTO();
        turnoADevolver.setFecha(turnoGuardado.getFecha());
        turnoADevolver.setPaciente_id(turnoGuardado.getPaciente().getId());
        turnoADevolver.setOdontologo_id(turnoGuardado.getOdontologo().getId());
        turnoGuardado.setId(turnoGuardado.getId());*/
    }

    @Override
    public TurnoDTO leerTurno(Long id) {
        Optional<Turno> turno = turnoRepository.findById(id);
        TurnoDTO turnoDTO = null;
        if (turno.isPresent())
            turnoDTO = mapper.convertValue(turno, TurnoDTO.class);
        return turnoDTO;
    }

    @Override
    public void modificarTurno(TurnoDTO turnoDTO) {
        Turno turno = mapper.convertValue(turnoDTO, Turno.class);
        turnoRepository.save(turno);
    }

    @Override
    public void eliminarTurno(Long id) {
        turnoRepository.deleteById(id);
    }

    @Override
    public Set<TurnoDTO> listarTurnos() {
        List<Turno> turnos = turnoRepository.findAll();
        Set<TurnoDTO> turnoDTOSet = new HashSet<>();

        for (Turno turno: turnos) {
            turnoDTOSet.add(mapper.convertValue(turno, TurnoDTO.class));
        }
        return turnoDTOSet;
    }
}
