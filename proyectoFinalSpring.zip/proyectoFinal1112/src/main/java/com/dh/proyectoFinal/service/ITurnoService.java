package com.dh.proyectoFinal.service;


import com.dh.proyectoFinal.modelo.TurnoDTO;

import java.util.Set;

public interface ITurnoService {
    void agregarTurno(TurnoDTO turnoDTO);
    TurnoDTO leerTurno(Long id);
    void modificarTurno(TurnoDTO turnoDTO);
    void eliminarTurno(Long id);
    Set<TurnoDTO> listarTurnos();
}
