package com.dh.proyectoFinal.service;

public enum AppUsuarioRole {
    USER,ADMIN
}
