package com.dh.proyectoFinal.modelo;

public enum AppUserRole {
    USER,ADMIN
}
