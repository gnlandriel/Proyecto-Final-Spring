package com.dh.proyectoFinal.repository;

import com.dh.proyectoFinal.modelo.Turno;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ITurnoRepository extends JpaRepository<Turno, Long> {
}
