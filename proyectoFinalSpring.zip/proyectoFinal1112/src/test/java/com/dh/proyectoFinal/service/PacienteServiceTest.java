package com.dh.proyectoFinal;

import com.dh.proyectoFinal.modelo.PacienteDTO;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import com.dh.proyectoFinal.service.IPacienteService;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class PacienteServiceTest {

    @Autowired
    IPacienteService pacienteService;

    @Test
    public void testCrearPaciente() {
        PacienteDTO pacienteDTO = new PacienteDTO();
        pacienteDTO.setApellido("Sabina");
        pacienteDTO.setNombre("Joaquin");

        pacienteService.agregarPaciente(pacienteDTO);
        PacienteDTO pacienteDTO1 = pacienteService.leerPaciente(1L);

        assertTrue(pacienteDTO1 != null);
    }

}